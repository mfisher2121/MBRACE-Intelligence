# MBRACE DMV Electrification Intelligence App

A complete React Native (Expo) application for heat pump calculator, incentive finder, and market intelligence targeting the Maryland, DC, and Virginia region.

## Features

### 🧮 Calculator Suite
- **Heat Pump Savings Calculator** - 10-year cost comparison with rebates
- **Incentive Eligibility Finder** - State, utility, and federal programs
- **System Replacement Cost Estimator** - Equipment + labor breakdown
- **Risk Assessment** - Stranded asset analysis against ZEHES mandate

### 📚 Resource Playbooks
- **Nonprofit Buildings** - MEA ECB/EEE grant checklist (up to 100% covered)
- **Low-Income Housing** - DHCD/MEEHA/HEEHRA guide (up to $14,000/unit)
- **Contractor Resources** - Training, certifications, marketing for AI search

### 📊 PE Intelligence Layer
- **Maryland Electrification Index** - Portfolio-level risk mapping
- **Stranded Asset Matrix** - Asset-by-asset mandate exposure
- **Incentive Stacking Analysis** - Coverage % calculations
- **IC Memo Metrics** - Ready-to-use figures for investment committees

### 🎯 Lead Capture
- **Gated Results** - Email/phone required for full report (5-10x lift)
- **SMS Opt-in** - Automated nurture sequence ready
- **Firebase Integration** - Real-time lead database
- **Attribution Tracking** - UTM, contractor ID, source tracking

---

## Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Expo CLI: `npm install -g expo-cli`
- EAS CLI: `npm install -g eas-cli`
- Apple Developer Account (for iOS)
- Firebase project

### 1. Clone and Install

```bash
cd mbrace-app
npm install
```

### 2. Configure Firebase

Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)

1. Enable Firestore Database
2. Enable Analytics
3. Create a web app and get your config

Create `.env` file:

```env
EXPO_PUBLIC_FIREBASE_API_KEY=your-api-key
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
EXPO_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
EXPO_PUBLIC_FIREBASE_MEASUREMENT_ID=G-XXXXXXXX
```

### 3. Run Development Server

```bash
npx expo start
```

- Press `i` for iOS Simulator
- Press `a` for Android Emulator
- Scan QR code with Expo Go app on your device

---

## App Store Deployment

### iOS (App Store)

1. **Configure EAS**

```bash
# Login to your Apple Developer account
eas login

# Configure your project
eas build:configure
```

2. **Update `eas.json`**

Replace these values:
- `YOUR_APPLE_ID@email.com` - Your Apple ID
- `YOUR_APP_STORE_CONNECT_APP_ID` - From App Store Connect
- `YOUR_TEAM_ID` - Your Apple Developer Team ID

3. **Update `app.json`**

Replace `your-project-id-here` with your EAS project ID:
```bash
eas init
```

4. **Build for iOS**

```bash
# Development build (for testing)
eas build --platform ios --profile development

# Production build (for App Store)
eas build --platform ios --profile production
```

5. **Submit to App Store**

```bash
eas submit --platform ios
```

### Android (Google Play)

1. **Create Google Service Account**

- Go to Google Play Console
- Settings > API Access
- Create Service Account
- Download JSON key

2. **Update `eas.json`**

Set `serviceAccountKeyPath` to your key file location

3. **Build and Submit**

```bash
# Build
eas build --platform android --profile production

# Submit
eas submit --platform android
```

---

## App Store Assets Required

### App Icon
- **Size**: 1024x1024 PNG (no transparency)
- **Location**: `assets/icon.png`

### Splash Screen
- **Size**: 1242x2436 PNG
- **Location**: `assets/splash.png`

### Screenshots (iOS)
Create these sizes for App Store Connect:
- 6.7" (1290x2796) - iPhone 14 Pro Max
- 6.5" (1284x2778) - iPhone 14 Plus
- 5.5" (1242x2208) - iPhone 8 Plus

### App Store Metadata

**App Name**: MBRACE Heat Pump Calculator

**Subtitle**: Maryland Rebates Made Easy

**Keywords**: heat pump,maryland,rebate,hvac,empower,incentive,calculator,energy,savings,dc,virginia

**Description** (4000 chars max):
```
Calculate your heat pump savings and find available rebates in Maryland, DC, and Virginia.

FEATURES:
• Calculate total available incentives (up to $10,000+)
• See 10-year savings projections
• Find state, utility, and federal rebates
• Track Maryland's 2029 ZEHES mandate timeline
• Access step-by-step funding playbooks

INCENTIVE PROGRAMS COVERED:
• Maryland Energy Administration (MEA) - Up to $8,000
• EmPOWER Maryland utility rebates
• DC Sustainable Energy Utility (DCSEU)
• Virginia HEEHRA Program (100% coverage for low-income)
• Federal IRA 25C Tax Credit - $2,000

RESOURCES FOR:
• Homeowners planning heat pump installations
• Nonprofit organizations seeking free upgrades
• Affordable housing owners/operators
• HVAC contractors expanding services

The Maryland 2029 Zero-Emission Heating Equipment Standard (ZEHES) mandate is approaching. Early adopters benefit from maximum incentives and contractor availability.

Download now to discover your savings potential.
```

**Privacy Policy URL**: `https://mbrace.io/privacy`

---

## Project Structure

```
mbrace-app/
├── app/                      # Expo Router screens
│   ├── _layout.tsx           # Root navigation
│   ├── index.tsx             # Home screen
│   ├── consultation.tsx      # Booking screen
│   ├── calculator/           # Calculator flow
│   │   ├── location.tsx      # Step 1: Zip code
│   │   ├── home-type.tsx     # Step 2: Home type
│   │   ├── current-system.tsx # Step 3: Heating system
│   │   ├── income.tsx        # Step 4: Income bracket
│   │   ├── contact.tsx       # Step 5: Lead capture
│   │   └── results.tsx       # Step 6: Results
│   ├── playbooks/            # Resource guides
│   │   ├── index.tsx         # Playbook selection
│   │   ├── nonprofit.tsx     # Nonprofit guide
│   │   ├── low-income.tsx    # Low-income housing
│   │   └── contractor.tsx    # Contractor resources
│   └── intelligence/         # PE dashboard
│       └── index.tsx         # Market intelligence
├── components/               # Reusable components
│   └── ui.tsx               # Button, Card, Input, etc.
├── lib/                     # Core logic
│   ├── calculator.ts        # Rebate calculations
│   ├── constants.ts         # DMV incentive data
│   ├── firebase.ts          # Database & analytics
│   └── store.tsx            # State management
├── assets/                  # Images & fonts
├── app.json                 # Expo configuration
├── eas.json                 # EAS Build configuration
└── package.json
```

---

## Customization

### Update Incentive Data

Edit `lib/constants.ts`:

```typescript
export const INCENTIVE_PROGRAMS = {
  maryland: {
    programs: [
      {
        id: 'mea-residential',
        name: 'Maryland Energy Administration',
        amounts: {
          low: 8000,      // Update amounts
          moderate: 4000,
          // ...
        },
      },
    ],
  },
};
```

### Add New Utility Territories

```typescript
export const UTILITY_TERRITORIES = {
  newUtility: {
    id: 'new-utility',
    name: 'New Utility Company',
    state: 'MD',
    zipPrefixes: ['210', '211'],
    empowerParticipant: true,
  },
};
```

### Modify Calculator Logic

Edit `lib/calculator.ts`:

```typescript
function calculateStateRebate(state: string, incomeBracket: string): number {
  // Your custom logic
}
```

---

## Firebase Schema

### Collections

**leads**
```javascript
{
  email: string,
  phone: string,
  smsOptIn: boolean,
  zipCode: string,
  homeType: string,
  currentHeating: string,
  systemAge: string,
  incomeBracket: string,
  calculatedResults: {
    totalIncentives: number,
    netCost: number,
    annualSavings: number,
    // ...
  },
  source: string,
  utmSource: string,
  createdAt: timestamp,
  status: 'new' | 'contacted' | 'qualified' | 'converted',
  
  // PE Intelligence fields (for aggregation)
  _state: string,
  _utility: string,
  _riskScore: number,
  _incentiveCoverage: number,
}
```

**consultation_requests**
```javascript
{
  leadId: string,
  email: string,
  phone: string,
  preferredTime: string,
  notes: string,
  source: string,
  createdAt: timestamp,
  status: 'pending' | 'scheduled' | 'completed',
}
```

---

## Webhook Integration (n8n/Make)

When a lead is saved, trigger your automation:

```javascript
// In lib/firebase.ts, after saveLead()
fetch('https://your-n8n-webhook.com/lead', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: leadData.email,
    phone: leadData.phone,
    totalIncentives: results.totalIncentives,
    // ...
  }),
});
```

---

## Timeline to App Store

| Week | Milestone |
|------|-----------|
| 1 | Customize branding, update Firebase config |
| 2 | Test all flows, create screenshots |
| 3 | Submit to App Store, address feedback |
| 4 | Approved and live |

---

## Support

For questions about this codebase or MBRACE partnership opportunities, contact [your email].

---

## License

Proprietary - MBRACE Intelligence Engine
