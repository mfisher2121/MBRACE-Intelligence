// Home Screen - Main Entry Point
import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { THEME, KEY_DATES } from '../lib/constants';
import { Card, Badge } from '../components/ui';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();

  const handleCalculatorStart = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push('/calculator/location');
  };

  const handlePlaybooksOpen = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push('/playbooks');
  };

  const handleIntelligenceOpen = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push('/intelligence');
  };

  return (
    <View style={styles.container}>
      {/* Hero Section */}
      <LinearGradient
        colors={['#1a365d', '#0f172a']}
        style={styles.hero}
      >
        <View style={styles.heroContent}>
          <View style={styles.logoContainer}>
            <Text style={styles.logoText}>MBRACE</Text>
            <Text style={styles.logoSubtext}>Intelligence Engine</Text>
          </View>
          
          <Text style={styles.heroTitle}>
            Calculate Your{'\n'}Heat Pump Savings
          </Text>
          
          <Text style={styles.heroSubtitle}>
            Discover how much you can save with Maryland, DC, and Virginia's heat pump incentives
          </Text>

          {/* Urgency Banner */}
          <View style={styles.urgencyBanner}>
            <Ionicons name="time-outline" size={18} color="#f97316" />
            <Text style={styles.urgencyText}>
              Maryland 2029 mandate approaching — Act now for maximum incentives
            </Text>
          </View>

          {/* Main CTA */}
          <TouchableOpacity 
            style={styles.mainCta}
            onPress={handleCalculatorStart}
            activeOpacity={0.9}
          >
            <LinearGradient
              colors={['#0d9488', '#0f766e']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.mainCtaGradient}
            >
              <Text style={styles.mainCtaText}>Calculate My Savings</Text>
              <Ionicons name="arrow-forward" size={20} color="#fff" />
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.ctaSubtext}>
            Free • 3 minutes • No signup required
          </Text>
        </View>
      </LinearGradient>

      {/* Content Section */}
      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.contentContainer}
      >
        {/* Value Props */}
        <View style={styles.valueProps}>
          <View style={styles.valueProp}>
            <View style={styles.valuePropIcon}>
              <Ionicons name="cash-outline" size={24} color={THEME.colors.secondary} />
            </View>
            <Text style={styles.valuePropTitle}>Up to $10,000+</Text>
            <Text style={styles.valuePropText}>in stacked incentives</Text>
          </View>
          
          <View style={styles.valueProp}>
            <View style={styles.valuePropIcon}>
              <Ionicons name="flash-outline" size={24} color={THEME.colors.secondary} />
            </View>
            <Text style={styles.valuePropTitle}>$400-$1,400</Text>
            <Text style={styles.valuePropText}>annual savings</Text>
          </View>
          
          <View style={styles.valueProp}>
            <View style={styles.valuePropIcon}>
              <Ionicons name="shield-checkmark-outline" size={24} color={THEME.colors.secondary} />
            </View>
            <Text style={styles.valuePropTitle}>2029 Ready</Text>
            <Text style={styles.valuePropText}>mandate compliant</Text>
          </View>
        </View>

        {/* Quick Links */}
        <Text style={styles.sectionTitle}>Resources</Text>
        
        <TouchableOpacity 
          style={styles.resourceCard}
          onPress={handlePlaybooksOpen}
          activeOpacity={0.7}
        >
          <View style={styles.resourceCardIcon}>
            <Ionicons name="document-text" size={28} color={THEME.colors.primary} />
          </View>
          <View style={styles.resourceCardContent}>
            <Text style={styles.resourceCardTitle}>Funding Playbooks</Text>
            <Text style={styles.resourceCardText}>
              Step-by-step guides for nonprofits, affordable housing, and contractors
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={THEME.colors.text.light} />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.resourceCard}
          onPress={handleIntelligenceOpen}
          activeOpacity={0.7}
        >
          <View style={styles.resourceCardIcon}>
            <Ionicons name="analytics" size={28} color={THEME.colors.primary} />
          </View>
          <View style={styles.resourceCardContent}>
            <Text style={styles.resourceCardTitle}>Market Intelligence</Text>
            <Text style={styles.resourceCardText}>
              DMV mandate timeline, incentive updates, and market analysis
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={THEME.colors.text.light} />
        </TouchableOpacity>

        {/* Mandate Timeline */}
        <Text style={styles.sectionTitle}>Key Dates</Text>
        
        <Card variant="outlined" style={styles.timelineCard}>
          {Object.entries(KEY_DATES).map(([key, item], index) => (
            <View 
              key={key} 
              style={[
                styles.timelineItem,
                index < Object.keys(KEY_DATES).length - 1 && styles.timelineItemBorder
              ]}
            >
              <View style={styles.timelineDate}>
                <Text style={styles.timelineDateText}>{item.date}</Text>
              </View>
              <Text style={styles.timelineDescription}>{item.description}</Text>
            </View>
          ))}
        </Card>

        {/* Trust Indicators */}
        <View style={styles.trustSection}>
          <Text style={styles.trustText}>
            Data sourced from Maryland Energy Administration, DCSEU, Virginia HEEHRA, and IRA guidelines
          </Text>
        </View>

        {/* Bottom Padding */}
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  hero: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
  },
  heroContent: {
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  logoText: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    letterSpacing: 2,
  },
  logoSubtext: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: THEME.colors.secondary,
    letterSpacing: 1,
    marginTop: 4,
  },
  heroTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    textAlign: 'center',
    lineHeight: 36,
  },
  heroSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 24,
  },
  urgencyBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(249, 115, 22, 0.15)',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginTop: 20,
  },
  urgencyText: {
    fontSize: 13,
    fontFamily: 'Inter-Medium',
    color: '#f97316',
    marginLeft: 8,
  },
  mainCta: {
    width: '100%',
    marginTop: 24,
  },
  mainCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    borderRadius: 12,
  },
  mainCtaText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
    marginRight: 8,
  },
  ctaSubtext: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255,255,255,0.6)',
    marginTop: 12,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 24,
  },
  valueProps: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 32,
  },
  valueProp: {
    alignItems: 'center',
    flex: 1,
  },
  valuePropIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f0fdfa',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  valuePropTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.text.primary,
  },
  valuePropText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
    marginBottom: 16,
  },
  resourceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: THEME.colors.border,
  },
  resourceCardIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#f0fdfa',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  resourceCardContent: {
    flex: 1,
  },
  resourceCardTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
  },
  resourceCardText: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    marginTop: 2,
  },
  timelineCard: {
    marginBottom: 24,
  },
  timelineItem: {
    flexDirection: 'row',
    paddingVertical: 12,
  },
  timelineItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: THEME.colors.border,
  },
  timelineDate: {
    width: 80,
    marginRight: 16,
  },
  timelineDateText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.secondary,
  },
  timelineDescription: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.primary,
    lineHeight: 20,
  },
  trustSection: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  trustText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.light,
    textAlign: 'center',
    lineHeight: 18,
  },
});
