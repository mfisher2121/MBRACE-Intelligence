// Market Intelligence - PE Fund Manager Dashboard
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { THEME, KEY_DATES, PE_METRICS, INCENTIVE_PROGRAMS } from '../../lib/constants';
import { Card, Badge, Button, Divider, StatCard } from '../../components/ui';

const MANDATE_TIMELINE = [
  { year: '2025-26', event: 'ZEHES rules begin phasing in', status: 'active' },
  { year: '2029', event: 'End-of-life replacements must be zero-emission', status: 'upcoming' },
  { year: '2030', event: '95% heat pump sales target (MD)', status: 'upcoming' },
  { year: '2030', event: '65% heat pump market share (DMV MOU)', status: 'upcoming' },
  { year: '2035', event: 'All new construction must be all-electric', status: 'future' },
  { year: '2040s', event: 'Nearly all buildings electrified', status: 'future' },
];

const PE_VALUE_PROPS = [
  {
    title: 'Portfolio Heat Pump Readiness Scan',
    description: 'Map your entire portfolio against the mandate timeline. See risk exposure and incremental capex requirements.',
    icon: 'map-outline',
  },
  {
    title: 'Incentive Stacking Analysis',
    description: 'Calculate stacked incentive coverage as % of project cost for each asset class.',
    icon: 'layers-outline',
  },
  {
    title: 'Standardized Upgrade SOPs',
    description: 'Ready-to-use checklists for operating partners. Complex policy → repeatable process.',
    icon: 'document-text-outline',
  },
];

const ASSET_RISK_MATRIX = [
  { type: 'Oil Boiler', risk: 'Critical', score: 9, recommendation: 'Immediate action' },
  { type: 'Propane Furnace', risk: 'Very High', score: 8, recommendation: 'Plan within 12 months' },
  { type: 'Gas Furnace', risk: 'High', score: 7, recommendation: 'Plan within 24 months' },
  { type: 'Electric Resistance', risk: 'Moderate', score: 5, recommendation: 'High savings opportunity' },
  { type: 'Existing Heat Pump', risk: 'Low', score: 2, recommendation: 'Upgrade opportunity' },
];

export default function IntelligenceScreen() {
  const router = useRouter();

  const handleContactSales = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push('/consultation');
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <LinearGradient
          colors={[THEME.colors.primary, '#0f172a']}
          style={styles.headerGradient}
        >
          <Badge text="Portfolio Intelligence" variant="info" />
          <Text style={styles.headerTitle}>Maryland Electrification Index</Text>
          <Text style={styles.headerSubtitle}>
            Translate regulatory mandates into actionable financial metrics for your portfolio
          </Text>
        </LinearGradient>

        {/* Key Metrics */}
        <View style={styles.metricsSection}>
          <Text style={styles.sectionLabel}>PE Intelligence Metrics</Text>
          
          <View style={styles.metricsRow}>
            <Card variant="elevated" style={styles.metricCard}>
              <Text style={styles.metricLabel}>Incremental Net Benefit</Text>
              <Text style={styles.metricValue}>
                ${PE_METRICS.incrementalNetBenefit.min.toLocaleString()}-${PE_METRICS.incrementalNetBenefit.max.toLocaleString()}
              </Text>
              <Text style={styles.metricPeriod}>per building / {PE_METRICS.incrementalNetBenefit.period}</Text>
            </Card>
          </View>

          <View style={styles.metricsGrid}>
            <View style={styles.metricSmall}>
              <Text style={styles.metricSmallLabel}>Oil/Propane Payback</Text>
              <Text style={styles.metricSmallValue}>{PE_METRICS.paybackPeriod.oilPropane} yrs</Text>
            </View>
            <View style={styles.metricSmall}>
              <Text style={styles.metricSmallLabel}>Gas Payback</Text>
              <Text style={styles.metricSmallValue}>{PE_METRICS.paybackPeriod.gas} yrs</Text>
            </View>
            <View style={styles.metricSmall}>
              <Text style={styles.metricSmallLabel}>Annual Savings</Text>
              <Text style={styles.metricSmallValue}>$400-1,400</Text>
            </View>
          </View>
        </View>

        {/* Stranded Asset Risk */}
        <Text style={styles.sectionLabel}>Stranded Asset Risk Matrix</Text>
        <Card variant="outlined" style={styles.riskMatrixCard}>
          <Text style={styles.riskMatrixIntro}>
            Assets mapped against ZEHES 2029+ mandate timeline
          </Text>
          
          {ASSET_RISK_MATRIX.map((asset, index) => (
            <View 
              key={index} 
              style={[
                styles.riskRow,
                index < ASSET_RISK_MATRIX.length - 1 && styles.riskRowBorder
              ]}
            >
              <View style={styles.riskAssetInfo}>
                <Text style={styles.riskAssetType}>{asset.type}</Text>
                <Text style={styles.riskRecommendation}>{asset.recommendation}</Text>
              </View>
              <View style={styles.riskScoreContainer}>
                <View style={[
                  styles.riskBadge,
                  asset.score >= 8 && styles.riskBadgeCritical,
                  asset.score >= 6 && asset.score < 8 && styles.riskBadgeHigh,
                  asset.score >= 4 && asset.score < 6 && styles.riskBadgeModerate,
                  asset.score < 4 && styles.riskBadgeLow,
                ]}>
                  <Text style={styles.riskBadgeText}>{asset.risk}</Text>
                </View>
                <Text style={styles.riskScoreText}>Score: {asset.score}/10</Text>
              </View>
            </View>
          ))}
        </Card>

        {/* Mandate Timeline */}
        <Text style={styles.sectionLabel}>Regulatory Timeline</Text>
        <Card variant="outlined" style={styles.timelineCard}>
          {MANDATE_TIMELINE.map((item, index) => (
            <View 
              key={index}
              style={[
                styles.timelineItem,
                index < MANDATE_TIMELINE.length - 1 && styles.timelineItemBorder
              ]}
            >
              <View style={[
                styles.timelineDot,
                item.status === 'active' && styles.timelineDotActive,
                item.status === 'upcoming' && styles.timelineDotUpcoming,
                item.status === 'future' && styles.timelineDotFuture,
              ]} />
              <View style={styles.timelineContent}>
                <Text style={styles.timelineYear}>{item.year}</Text>
                <Text style={styles.timelineEvent}>{item.event}</Text>
              </View>
            </View>
          ))}
        </Card>

        {/* Incentive Programs by State */}
        <Text style={styles.sectionLabel}>Incentive Programs by Jurisdiction</Text>
        
        {Object.entries(INCENTIVE_PROGRAMS).map(([key, program]) => (
          <Card key={key} variant="outlined" style={styles.programCard}>
            <View style={styles.programHeader}>
              <Text style={styles.programState}>{program.name}</Text>
              <Badge 
                text={program.mandate.targetYear.toString()} 
                variant="warning"
              />
            </View>
            <Text style={styles.programMandate}>{program.mandate.description}</Text>
            <Text style={styles.programTarget}>{program.mandate.salesTarget}</Text>
            
            <Divider style={{ marginVertical: 12 }} />
            
            <Text style={styles.programsLabel}>Available Programs:</Text>
            {program.programs.map((p, i) => (
              <View key={i} style={styles.programItem}>
                <Text style={styles.programName}>{p.name}</Text>
                <Text style={styles.programDescription}>{p.description}</Text>
              </View>
            ))}
          </Card>
        ))}

        {/* PE Deliverables */}
        <Text style={styles.sectionLabel}>Deliverables for Investment Committees</Text>
        {PE_VALUE_PROPS.map((prop, index) => (
          <Card key={index} variant="outlined" style={styles.deliverableCard}>
            <View style={styles.deliverableHeader}>
              <View style={styles.deliverableIcon}>
                <Ionicons name={prop.icon as any} size={24} color={THEME.colors.primary} />
              </View>
              <Text style={styles.deliverableTitle}>{prop.title}</Text>
            </View>
            <Text style={styles.deliverableDescription}>{prop.description}</Text>
          </Card>
        ))}

        {/* IC Memo Stats */}
        <Card variant="elevated" style={styles.memoCard}>
          <Text style={styles.memoTitle}>Key Figures for IC Memos</Text>
          
          <View style={styles.memoStat}>
            <Text style={styles.memoStatLabel}>Energy-Cost Delta</Text>
            <Text style={styles.memoStatValue}>
              "Average homes save $400-1,400/year, improving NOI"
            </Text>
          </View>
          
          <View style={styles.memoStat}>
            <Text style={styles.memoStatLabel}>Capex Risk</Text>
            <Text style={styles.memoStatValue}>
              "Stranded asset risk could reach tens of billions across DMV"
            </Text>
          </View>
          
          <View style={styles.memoStat}>
            <Text style={styles.memoStatLabel}>Payback Period</Text>
            <Text style={styles.memoStatValue}>
              "Oil/propane conversions: ~4 years with full incentives"
            </Text>
          </View>
        </Card>

        {/* CTA */}
        <View style={styles.ctaSection}>
          <Button
            title="Request Portfolio Analysis"
            onPress={handleContactSales}
            size="large"
            icon="arrow-forward"
          />
          <Text style={styles.ctaSubtext}>
            Schedule a briefing on electrification risk for your portfolio
          </Text>
        </View>

        {/* Bottom Padding */}
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 0,
  },
  headerGradient: {
    padding: 24,
    paddingTop: 16,
    paddingBottom: 32,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    marginTop: 12,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255,255,255,0.8)',
    lineHeight: 24,
  },
  metricsSection: {
    padding: 24,
    paddingTop: 0,
    marginTop: -16,
  },
  sectionLabel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.secondary,
    marginBottom: 12,
    marginTop: 16,
    paddingHorizontal: 24,
  },
  metricsRow: {
    marginBottom: 12,
  },
  metricCard: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  metricLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: THEME.colors.text.secondary,
  },
  metricValue: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.success,
    marginVertical: 4,
  },
  metricPeriod: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.light,
  },
  metricsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  metricSmall: {
    flex: 1,
    backgroundColor: THEME.colors.surface,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.colors.border,
  },
  metricSmallLabel: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: THEME.colors.text.secondary,
    textAlign: 'center',
  },
  metricSmallValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.text.primary,
    marginTop: 4,
  },
  riskMatrixCard: {
    marginHorizontal: 24,
    marginBottom: 16,
  },
  riskMatrixIntro: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    marginBottom: 16,
  },
  riskRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  riskRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: THEME.colors.border,
  },
  riskAssetInfo: {
    flex: 1,
  },
  riskAssetType: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
  },
  riskRecommendation: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    marginTop: 2,
  },
  riskScoreContainer: {
    alignItems: 'flex-end',
  },
  riskBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 4,
    marginBottom: 4,
  },
  riskBadgeCritical: {
    backgroundColor: '#fef2f2',
  },
  riskBadgeHigh: {
    backgroundColor: '#fef3c7',
  },
  riskBadgeModerate: {
    backgroundColor: '#e0f2fe',
  },
  riskBadgeLow: {
    backgroundColor: '#dcfce7',
  },
  riskBadgeText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
  },
  riskScoreText: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.light,
  },
  timelineCard: {
    marginHorizontal: 24,
    marginBottom: 16,
  },
  timelineItem: {
    flexDirection: 'row',
    paddingVertical: 12,
  },
  timelineItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: THEME.colors.border,
  },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
    marginTop: 4,
  },
  timelineDotActive: {
    backgroundColor: THEME.colors.success,
  },
  timelineDotUpcoming: {
    backgroundColor: THEME.colors.warning,
  },
  timelineDotFuture: {
    backgroundColor: THEME.colors.text.light,
  },
  timelineContent: {
    flex: 1,
  },
  timelineYear: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.text.primary,
  },
  timelineEvent: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    marginTop: 2,
  },
  programCard: {
    marginHorizontal: 24,
    marginBottom: 12,
  },
  programHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  programState: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: THEME.colors.text.primary,
  },
  programMandate: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.primary,
    lineHeight: 20,
  },
  programTarget: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: THEME.colors.secondary,
    marginTop: 4,
  },
  programsLabel: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.secondary,
    marginBottom: 8,
  },
  programItem: {
    marginBottom: 8,
  },
  programName: {
    fontSize: 13,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
  },
  programDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
  },
  deliverableCard: {
    marginHorizontal: 24,
    marginBottom: 12,
  },
  deliverableHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  deliverableIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#f0fdfa',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  deliverableTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: THEME.colors.text.primary,
    flex: 1,
  },
  deliverableDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    lineHeight: 20,
  },
  memoCard: {
    marginHorizontal: 24,
    marginTop: 8,
    marginBottom: 24,
    backgroundColor: THEME.colors.primary,
  },
  memoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
    marginBottom: 16,
  },
  memoStat: {
    marginBottom: 12,
  },
  memoStatLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: 'rgba(255,255,255,0.7)',
  },
  memoStatValue: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#fff',
    fontStyle: 'italic',
    marginTop: 2,
  },
  ctaSection: {
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  ctaSubtext: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    color: THEME.colors.text.secondary,
    marginTop: 12,
    textAlign: 'center',
  },
});
